<?php

namespace AppBundle\Event;

final class Task
{
    const PRE_CREATION  = 'app.task.pre_create';
    const POST_CREATION = 'app.task.post_create';
}
